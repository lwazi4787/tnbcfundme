<?php
	include 'functions.php';
	viewpostscategories();
?>
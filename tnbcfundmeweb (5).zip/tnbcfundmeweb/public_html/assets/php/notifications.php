<?php
	/*session_start();
	include 'db_access.php';

	$email = $_SESSION['emai'];

	$sql = "SELECT * FROM `comments` WHERE `User email` = '$email' AND `notifications` = '0'";

	$sql_run = mysqli_query($db_access, $sql);

	$num_notifications = mysqli_num_rows($sql_run);*/



		include 'db_access.php';

		$email = $_SESSION['emai'];

		$sql = "SELECT * FROM `posts` WHERE `User email` = '$email'";

		$x = 0;

		$sql_run = mysqli_query($db_access, $sql);

		//$num_notifications = mysqli_num_rows($sql_run);

		while($rows = mysqli_fetch_assoc($sql_run))
		{
			$postid = $rows['Id'];

			$sql0 = "SELECT * FROM `comments` WHERE `Post id` = '$postid' AND `notifications` = '0' ORDER BY `Id` DESC";

			$sql_run0 = mysqli_query($db_access, $sql0);


			while($rows0 = mysqli_fetch_assoc($sql_run0))
			{
				$comment = $rows0['Comment'];
				$getcid = $rows0['Comment n PID'];
				$PID = $rows0['Comment Id'];
				$Useremail = $rows0['User email'];
				$x++;
			}

			

		}
?>
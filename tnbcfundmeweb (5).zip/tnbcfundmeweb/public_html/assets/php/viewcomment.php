<?php
	include 'functions.php';
	viewComment();
?>
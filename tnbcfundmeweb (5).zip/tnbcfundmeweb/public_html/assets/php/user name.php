<?php

	include 'db_access.php';
	//session_start();


	$email = $_SESSION['emai'];


    $sql = "SELECT * FROM `users` WHERE `Email` = '$email'";

    $sqlrun  = mysqli_query($db_access, $sql);

    $row = mysqli_fetch_assoc($sqlrun);


    $name = $row['Name'];
    $surname = $row['Last name'];


?>
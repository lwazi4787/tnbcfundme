<?php
	function signin()
	{
		include 'db_access.php';
		$name = $_POST['name'];
		$lastname = $_POST['lname'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$signingkey = $_POST['signingkey'];
		//$cause = $_POST['cause'];

		trim($name);
	    stripslashes($name);
	    htmlspecialchars($name);
	    
	    trim($lastname);
	    stripslashes($lastname);
	    htmlspecialchars($lastname);
	    
	    trim($email);
	    stripslashes($email);
	    htmlspecialchars($email);
	    
	    trim($password);
	    stripslashes($password);
	    htmlspecialchars($password);

	    trim($signingkey);
	    stripslashes($signingkey);
	    htmlspecialchars($signingkey);

	    //trim($cause);
	    //stripslashes($cause);
	    //htmlspecialchars($cause);

	    $code = rand(1000, 10000);

	    //repeat email
	    $qry0 = "SELECT * FROM `users` WHERE `randomIntEmail` = '$code'";
	    $sql_run0 = mysqli_query($db_access, $qry);

	    while(mysqli_num_rows($sql_run0) >= 1)
	    {
	        $code = rand(1000, 10000);
	    }

	    /*while($rows = mysqli_fetch_assoc($sql_run0))
	    {
	    	if($rows['randomIntEmail'] == $code)
	    	{
	    		$code = random(1000, 10000);
	    	}
	    }*/


	    //repeat email
	    $qry = "SELECT * FROM `users` WHERE `Email` = '$email'";
	    
	    $sql_run = mysqli_query($db_access, $qry);

	    
	    if(mysqli_num_rows($sql_run) >= 1)
	    {
	        header('Location: ../../email.php');
	        die();
	    }


		$sql = "INSERT INTO `users` (`Id`, `Name`, `Last name`, `Email`, `Password`, `signingkey`, `randomIntEmail`, `emailConfirmInt`, `recover`) VALUES (NULL, '$name', '$lastname', '$email', '$password', '$signingkey', '$code', '0', '0')";


		$sql_run = mysqli_query($db_access, $sql);


		//header('Location: ../../loging.php');

		header('Location: ../../confirmEmail.php');
	}

	function passRecovery()
	{
		include "db_access.php";

		session_start();

		$code = rand(1000, 10000);

	    //repeat email
	    $qry0 = "SELECT * FROM `users` WHERE `randomIntEmail` = '$code'";
	    $sql_run0 = mysqli_query($db_access, $qry);

	    while(mysqli_num_rows($sql_run0) >= 1)
	    {
	        $code = rand(1000, 10000);
	    }

		$sql = "UPDATE `users` SET `recover` = '100' WHERE `users`.`Id` = '$code'";

		$sql_run = mysqli_query($db_access, $sql);

		mail($to, $heading, $code);

		header('Location: ../../recoverd.php');
	}

	function passRecoverd()
	{
		include "db_access.php";

		$code = $_POST['code'];
		$pass = $_POST['newpass'];

		$sql = "SELECT * FROM `users` WHERE `recover` = '$code'";
		$sql_run = mysqli_query($db_access, $sql);

		if(mysqli_num_rows($sql_run) >= 1)
		{
			$sql = "UPDATE `users` SET `Password` = '$pass' WHERE `users`.`recover` = '$code'";
			$sql_run = mysql_fetch_assoc($sql);
		}
	}

	function confrmemail()
	{
		include 'db_access.php';

		$code = $_POST['emailconf'];

		$sql0 = "SELECT * FROM `users` WHERE `randomIntEmail` = '$code'";

		$sql_run0 = mysqli_query($db_access, $sql0);

		$rowfound = mysqli_num_rows($sql_run0);

		if($rowfound >= 1)
		{
			$sql = "UPDATE `users` SET `emailConfirmInt` = '1' WHERE `users`.`randomIntEmail` = '$code'";
			$sql_run = mysqli_query($db_access, $sql);

			header('Location: ../../loging.php');
		}
		else
		{
			header('Location: ../../confirmEmail.php');
		}
		
	}

	function login()
	{
		session_start();
		include 'db_access.php';

		$email = $_POST['email'];
		$password = $_POST['password'];

		trim($email);
	    stripslashes($email);
	    htmlspecialchars($email);
	    
	    trim($password);
	    stripslashes($password);
	    htmlspecialchars($password);

		$_SESSION['emai'] = $email;
		$_SESSION['logedin'] = 0;

		$sql = "SELECT * FROM `users` WHERE `Email` = '$email' AND `Password` = '$password' AND `emailConfirmInt` = '1'";

		$sql_run = mysqli_query($db_access, $sql);

		if(mysqli_num_rows($sql_run) >= 1)
		{
			$_SESSION['logedin'] = 1;
			header('Location: ../../posts.php');
		}
		else
		{
			//session_destroy();
			header('Location: ../../loging-fail.php');
		}
	}

	function logout()
	{
		session_start();

		session_destroy();
		header('Location: ../../loging.php');
	}

	function post()
	{
		session_start();
		include 'db_access.php';

		$email = $_SESSION['emai'];
		$heading = $_POST['heading'];
		$Body = $_POST['body'];
		$Category = $_POST['category'];

		$time_stamp = time();
    	$date = date('M-d-Y', $time_stamp);

		$sql = "INSERT INTO `posts` (`Id`, `Heading`, `Body`, `Category`, `Date`, `User email`) VALUES (NULL, '$heading', '$Body', '$Category', '$date', '$email')";
		$sql_run = mysqli_query($db_access, $sql);

		header('Location: ../../posts.php');
	}

	function editPost()
	{
		session_start();

		include'db_access.php';

		echo $id = $_POST['id'];
		echo $heading = $_POST['heading'];
		echo $category = $_POST['category'];
		echo $body = $_POST['body'];

		$sql = "UPDATE `posts` SET `Heading` = '$heading', `Body` = '$body', `Category` = '$category' WHERE `posts`.`Id` = '$id'";
		mysqli_query($db_access, $sql);

		header('Location: ../../posts.php');

		//UPDATE `posts` SET `Heading` = 'Heading2', `Body` = 'Need Some Coins2', `Category` = 'Project' WHERE `posts`.`Id` = 31
	}

	function viewposts()
	{
		//session_start();
		include 'db_access.php';

		$email = $_SESSION['emai'];

		$xyz = 0;

		//$cat = $_GET['cat'];

		$sql = "SELECT * FROM `posts` ORDER BY `Id` DESC";

		$sql_run = mysqli_query($db_access, $sql);

		while($row = mysqli_fetch_assoc($sql_run))
		{
			$heading = $row['Heading'];
			$body = $row['Body'];
			$category = $row['Category'];
			$date = $row['Date'];
			$Id = $row['Id'];
			$Post_email = $row['User email'];

			$sql2 = "SELECT * FROM `users` WHERE `Email` = '$Post_email'";

			$sql_run2 = mysqli_query($db_access, $sql2);

			$row2 = mysqli_fetch_assoc($sql_run2);

			$name = $row2['Name'];
			$lname = $row2['Last name'];

			$sql4 = "SELECT * FROM `comments` WHERE `Post id` = '$Id'";

			$sql_run4 = mysqli_query($db_access, $sql4);

			$numCom = mysqli_num_rows($sql_run4);

			if(mysqli_num_rows($sql_run) == 0)
			{
				echo '<article class="entry">

             <!-- <div class="entry-img">
                <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid">
              </div>-->

              <h2 class="entry-title">
                <p>'.$heading.'</p>
              </h2>
              </article>';
			}
			else if($Post_email == $email)
			{
				echo '<article class="entry" id="art"> <b style="color: blue;"> <form action="makepost.php" method="post"><input type="hidden" value='.$Id.' name="id"><button type=submit class="cmmnt" id="edit"><i class="bi bi-pen edit"></i></button></form></b>

	             <!-- <div class="entry-img">
	                <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid">
	              </div>-->

	              <h2 class="entry-title">
	                <p>'.$heading.'</p>
	              </h2>

	              <div class="entry-meta">
	                <ul>
	                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <form action="profile.php" method="post"><input type="hidden" value='.$Post_email.' name="postemail"><button type=submit class="cmmnt">'.$name.' '.$lname.'</button></form></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="#"><time datetime="2020-01-01">'.$date.'</time></a></li>

	                  <li class="d-flex align-items-center"><!--<i class="bi bi-cash"></i>--> <form action="sendtnbc.php" method="post"><input type="hidden" value='.$Post_email.' name="postemail"> <button type=submit class="cmmnt"><img src="assets/img/icon.svg" style="width: 17%;">Send TNBCs</button></form></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-chat-dots"></i> <form action="blog-single.php" method="post"> <input type="hidden" value='.$Id.' name="PID"> <button type=submit class="cmmnt">'.$numCom.' Comments</button></form></li>
	                </ul>
	              </div>

	              <div class="entry-content">
	                <p>'.$body.'</p>
	                <form action="assets/php/makecomment.php" method="post">
	                	<input type="hidden" value='.$Id.' name="postId">
	                	<input type="hidden" value='.$email.' name="userEmail">

	                	<div class = "row">
	                		<div class = "col-md-10">
			                	<!--<input type="text" name="comment" class="comment">-->

			                	<div class="col form-group">
			                      <textarea name="comment" class="form-control" placeholder="Your Comment*"></textarea>
			                    </div>
			                </div>
			                <div class="col-md-2">
				           		
				                  <button type="submit" class="com-btn">Comment</button>
				                
			                </div>
		                </div>

	                </form>
	              </div>

	            </article>









	            <div class="modal-bg" id="modal-bg2">
			    <div class="mymodal">
			      
			      <div class="row">
			        <div>
			          <h3>Make Post <span class="right" id="closemodal">X</span></h3>
			        </div>
			      </div>
			      <hr>

			      <div>
			        <form action="assets/php/makepost.php" method = "post">

			          <div class="row">
			            
			            <div class="col-lg-12">
			              <input type="text" name="heading" class="input" value='.$heading.'><input type="text" name="heading" class="input" value='.$heading.'>
			            </div><br><br><br>

			            <div class="col-lg-12">
			              <label>Category</label>

			              <select name="category" class="section">

			                <option value="project">
			                  Project Idea
			                </option>

			                <option value="tnbgames">
			                  TNB Games
			                </option>


			                <option value="personal">
			                  Personal
			                </option>
			                
			              </select>
			            </div><br><br>

			          </div>

			          <div class="col form-group">
			            <textarea name="body" class="form-control" placeholder="Your Comment*"></textarea>
			          </div>
			          <hr>
			          <button type="submit" class="btn btn-primary">Make Post</button>
			        
			        </form>
			      </div>

			      <div>
			        <p></p>
			      </div>

			    </div>
			    </div>
	           ';
        	}
        	else
        	{
        		echo '<article class="entry" id="art">

	             <!-- <div class="entry-img">
	                <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid">
	              </div>-->

	              <h2 class="entry-title">
	                <p>'.$heading.'</p>
	              </h2>

	              <div class="entry-meta">
	                <ul>
	                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <form action="profile.php" method="post"><input type="hidden" value='.$Post_email.' name="postemail"><button type=submit class="cmmnt">'.$name.' '.$lname.'</button></form></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="#"><time datetime="2020-01-01">'.$date.'</time></a></li>

	                  <li class="d-flex align-items-center"><!--<i class="bi bi-cash"></i>--> <form action="sendtnbc.php" method="post"><input type="hidden" value='.$Post_email.' name="postemail"> <button type=submit class="cmmnt"><img src="assets/img/icon.svg" style="width: 17%;">Send TNBCs</button></form></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-chat-dots"></i> <form action="blog-single.php" method="post"> <input type="hidden" value='.$Id.' name="PID"> <button type=submit class="cmmnt">'.$numCom.' Comments</button></form></li>
	                </ul>
	              </div>

	              <div class="entry-content">
	                <p>'.$body.'</p>
	                <form action="assets/php/makecomment.php" method="post">
	                	<input type="hidden" value='.$Id.' name="postId">
	                	<input type="hidden" value='.$email.' name="userEmail">

	                	<div class = "row">
	                		<div class = "col-md-10">
			                	<!--<input type="text" name="comment" class="comment">-->

			                	<div class="col form-group">
			                      <textarea name="comment" class="form-control" placeholder="Your Comment*"></textarea>
			                    </div>
			                </div>
			                <div class="col-md-2">
				           		
				                  <button type="submit" class="com-btn">Comment</button>
				                
			                </div>
		                </div>

	                </form>
	              </div>

	            </article>

	            ';
        	}
		}
	}

	function makedms()
	{
		session_start();
		include 'db_access.php';

		$too = $_POST['too'];
		$msg = $_POST['msg'];
		$email = $_SESSION['emai'];

		$sql = "INSERT INTO `dms` (`id`, `Messages`, `Too`, `From`) VALUES (NULL, '$msg', '$too', '$email')";

		$sql_run = mysqli_query($db_access, $sql);
	}

	function viewdms()
	{
		session_start();

		include 'db_access.php';

		$too = $_POST['too'];
		$email = $_SESSION['emai'];

		$sql = "SELECT * FROM `dms` WHERE `Too` = '$too' AND `From` = '$email'";

	}

	function postcomment()
	{
		session_start();
		include 'db_access.php';

		$post_id = $_POST['postId'];
		$user_email = $_POST['userEmail'];
		$comment = $_POST['comment'];
		//echo $cat = $_POST['cat'];

		$_SESSION['cats'] = $_POST['cat'];

		//echo $_SESSION['cats'];

		$sql = "SELECT * FROM `comments` WHERE `Post id` = '$post_id' AND `User email` = '$user_email'";

		$sql_run = mysqli_query($db_access, $sql);

		$commntPID = mysqli_num_rows($sql_run)+1;

		$sql2 = "INSERT INTO `comments` (`Id`, `Comment`, `User email`, `Post id`, `Comment n PID`, `Comment Id`, `notifications`) VALUES (NULL, '$comment', '$user_email', '$post_id', '$commntPID', '0', '0')";

		$sql_run2 = mysqli_query($db_access, $sql2);

		header('Location: ../../posts.php?cat='.$_SESSION['cats']);
	}



	function postcommentcat()
	{
		session_start();
		include 'db_access.php';

		$post_id = $_POST['postId'];
		$user_email = $_POST['userEmail'];
		$comment = $_POST['comment'];
		//echo $cat = $_POST['cat'];

		$_SESSION['cats'] = $_POST['cat'];

		//echo $_SESSION['cats'];

		$sql = "SELECT * FROM `comments` WHERE `Post id` = '$post_id' AND `User email` = '$user_email'";

		$sql_run = mysqli_query($db_access, $sql);

		$commntPID = mysqli_num_rows($sql_run)+1;

		$sql2 = "INSERT INTO `comments` (`Id`, `Comment`, `User email`, `Post id`, `Comment n PID`, `Comment Id`, `notifications`) VALUES (NULL, '$comment', '$user_email', '$post_id', '$commntPID', '0', '0')";

		$sql_run2 = mysqli_query($db_access, $sql2);

		header('Location: ../../postcat.php?cat='.$_SESSION['cats']);
	}

	function viewComment()
	{
		//session_start();
		include 'db_access.php';

		$PID = $_POST['PID'];

		$sql = "SELECT * FROM `comments` WHERE `Post id` = '$PID' AND `Comment Id` = '0'";

		//$sql2 = "UPDATE `comments` SET `notifications` = '1' WHERE `comments`.`Id` = 17"

		$sql_run = mysqli_query($db_access, $sql);

		$_SESSION['ivbnhr'] = 0;

		while($row = mysqli_fetch_assoc($sql_run))
		{
			$comment = $row['Comment'];
			$cid = $row['Comment Id'];
			$useremail = $row['User email'];

			$comId = $row['Id'];

			$x = 1;


			$sql0 = "SELECT * FROM `users` WHERE `Email` = '$useremail'";

			$sql_run0 = mysqli_query($db_access, $sql0);

			$row = mysqli_fetch_assoc($sql_run0);

			$name = $row['Name'];
			$lname = $row['Last name'];
			

            echo '<div class="comment">
                <h5 class="postee"><a href="#">'.$name.' '.$lname.'</a> <form action="replay.php" method="post"><input type="hidden" name="cid" value='.$comId.' /><input type="hidden" name="pid" value='.$PID.' /><button type="submit" <i class="bi bi-reply-fill sub"></i> Reply</button></form><!--<button <i class="bi bi-reply-fill sub" id="sub"></i> Reply</button>--></h5>
                      <time datetime="2020-01-01">01 Jan, 2020</time>
                      <p class="comTxt">'.$comment.'
                      </p>
              </div>';


              /*echo '<div class="comment">
                <h5 class="postee"><a href="#">'.$name.' '.$lname.'</a><br> <button type="button" id="btnmodal" data-toggle="modal" data-target="#exampleModal" <i class="bi bi-reply-fill sub"></i> Reply</button></h5>
                      <time datetime="2020-01-01">01 Jan, 2020</time>
                      <p class="comTxt">'.$comment.'
                      </p>
              </div>';*/


            $x++;


            if(1)
            {
	            $sql2 = "SELECT * FROM `comments` WHERE `Post id` = '$PID' AND `Comment Id` = '$comId'";

	            $sql_run2 = mysqli_query($db_access, $sql2);

	            while($row2 = mysqli_fetch_assoc($sql_run2))
	            {
	            	$comment2 = $row2['Comment'];
	            	$useremail2 = $row2['User email'];
					//$cid = $row['Comment Id'];

					$sql3 = "SELECT * FROM `users` WHERE `Email` = '$useremail2'";

					$sql_run3 = mysqli_query($db_access, $sql3);

					$row3 = mysqli_fetch_assoc($sql_run3);

					$name3 = $row3['Name'];
					$lname3 = $row3['Last name'];




					echo '<div class="comment comment-reply">
	                <h5 class="postee"><a href="#">'.$name3.' '.$lname3.'</a> </h5>
	                      <time datetime="2020-01-01">01 Jan, 2020</time>
	                      <p>'.$comment2.'
	                      </p>
	              	</div>';
	            }
        	}
		}
	}

	function replay()
	{
		session_start();
		include 'db_access.php';

		$PID = $_POST['pid'];
		$cid = $_POST['cid'];
		$comment = $_POST['comment'];

		$email = $_SESSION['emai'];

		if($_SESSION['ivbnhr'] == 0)
		{
			$sql = "SELECT * FROM `comments` WHERE `Post id` = '$PID' AND `Comment Id` = '$cid'";

			$sql_run = mysqli_query($db_access, $sql);

			$row_num = mysqli_num_rows($sql_run);

			$cpid = $row_num + 1;


			$sql2 = "INSERT INTO `comments` (`Id`, `Comment`, `User email`, `Post id`, `Comment n PID`, `Comment Id`) VALUES (NULL, '$comment', '$email', '$PID', '$cpid', '$cid')";

			$sql_run2 = mysqli_query($db_access, $sql2);

			echo $_SESSION['ivbnhr'] = 0;

			$_SESSION['pid'] = $PID;
			$_SESSION['cid'] = $cid;

			//header("Location: ../../replay.php");
			header("Location: ../../replay.php?var1=".$PID.'&var2='.$cid);
		}
		/*elseif($_SESSION['ivbnhr'] = 1)
		{
			$PID = $_SESSION['pid'];
			$cid = $_SESSION['cid'];

			//$_SESSION['pid'] = $PID;
			//$_SESSION['cid'] = $cid;

			$sql = "SELECT * FROM `comments` WHERE `Post id` = '$PID' AND `Comment Id` = '$cid'";

			$sql_run = mysqli_query($db_access, $sql);

			$row_num = mysqli_num_rows($sql_run);

			$cpid = $row_num + 1;


			$sql2 = "INSERT INTO `comments` (`Id`, `Comment`, `User email`, `Post id`, `Comment n PID`, `Comment Id`) VALUES (NULL, '$comment', '$email', '$PID', '$cpid', '$cid')";

			$sql_run2 = mysqli_query($db_access, $sql2);

			//echo $_SESSION['ivbnhr'] = 0;

			header("Location: ../../replay.php?var1=".$PID.'&var2='.$cid);
		}*/
	}

	function getKeySign()
	{
		session_start();

		$email = $_SESSION['emai'];


		$sql = "SELECT * FROM `users` WHERE `Email` = '$email'";

		$sql_run = mysqli_query($db_access, $sql);

		$row = mysqli_fetch_assoc($sql_run);

		$signngkey = $row['signingkey'];
	}

	function notification()
	{
		//session_start();
		include 'db_access.php';

		$email = $_SESSION['emai'];

		//$sql = "SELECT * FROM `comments` WHERE `User email` = '$email' AND `notifications` = '0'";

		$sql = "SELECT * FROM `posts` WHERE `User email` = '$email'";

		$sql_run = mysqli_query($db_access, $sql);

		//$num_notifications = mysqli_num_rows($sql_run);

		while($rows = mysqli_fetch_assoc($sql_run))
		{
			$postid = $rows['Id'];

			$sql0 = "SELECT * FROM `comments` WHERE `Post id` = '$postid' AND `notifications` = '0' ORDER BY `Id` DESC";

			$sql_run0 = mysqli_query($db_access, $sql0);

			while($rows0 = mysqli_fetch_assoc($sql_run0))
			{
				$comment = $rows0['Comment'];
				$getcid = $rows0['Comment n PID'];
				$PID = $rows0['Comment Id'];
				$Useremail = $rows0['User email'];
				$id = $rows0['Id'];

				$sql2 = "SELECT * FROM `users` WHERE `Email` = '$Useremail'";

				$sql_run2 = mysqli_query($db_access, $sql2);

				$rows2 = mysqli_fetch_assoc($sql_run2);

				$name = $rows2['Name'];
				$lname = $rows2['Last name'];

				echo '
                  <form action="blog-single.php" method = "post">

                    <input type="hidden" name="cid" value='.$getcid.'>

                    <input type="hidden" name="PID" value='.$postid.'>

                    <input type="hidden" name="id" value='.$id.'>

				<button class="btn-ntificatn"><div class="notifications">
	              <p><b><i>'.$name.' '.$lname.'</i></b> commented on your post....</p>
	              <b>'.$comment.'</b>
	            </div></button></form>';
			}
		}

	}

	function changeNum()
	{
		include 'db_access.php';
		//session_start();

		//$id = $_POST['id'];

		if(array_key_exists('id', $_POST))
		{
			$id = $_POST['id'];
			$sql = "UPDATE `comments` SET `notifications` = '1' WHERE `comments`.`Id` = '$id'";

			$sql_run = mysqli_query($db_access, $sql);			
		}
	}

	function viewprofile()
	{
		include 'db_access.php';


		$email = $_POST['email'];


		$sql = "SELECT * `` FROM `` WHERE `` = ''";

		$sql_run = mysqli_query($db_access, $sql);


		$row = mysql_fetch_assoc($sql_run);


		$name = $row['Name'];
		$lname = $row['Last name'];
		$Email = $row['Email'];


		echo '<article class="entry"> <b style="color: blue;"></b>

               <!-- <div class="entry-img">
                  <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid">
                </div>-->

                <h2 class="entry-title">
                      <div class="row">
                    <div class="col-md-6">
                        <h6>Name: '.$name.'</h6>
                    </div>

                    <div class="col-md-6">
                        <h6>Last Name: '.$lnmae.'</h6>
                    </div><br><br>

                    <div class="col-md-6">
                        <h6>Email: '.$Email.'</h6>
                    </div>
                </div>
                </h2>

                <div class="entry-meta">
                  <ul>
                    
                  </ul>
                </div>

                <div class="entry-content">
                  <p></p>
                  
                </div>

              </article>';
	}




	function viewpostscategories()
	{
		//session_start();
		include 'db_access.php';

		$email = $_SESSION['emai'];

		$cat = $_GET['cat'];

		$sql = "SELECT * FROM `posts` WHERE `Category` = '$cat' ORDER BY `Id` DESC";

		$sql_run = mysqli_query($db_access, $sql);

		while($row = mysqli_fetch_assoc($sql_run))
		{
			$heading = $row['Heading'];
			$body = $row['Body'];
			$category = $row['Category'];
			$date = $row['Date'];
			$Id = $row['Id'];
			$Post_email = $row['User email'];

			$sql2 = "SELECT * FROM `users` WHERE `Email` = '$Post_email'";

			$sql_run2 = mysqli_query($db_access, $sql2);

			$row2 = mysqli_fetch_assoc($sql_run2);

			$name = $row2['Name'];
			$lname = $row2['Last name'];

			$sql4 = "SELECT * FROM `comments` WHERE `Post id` = '$Id'";

			$sql_run4 = mysqli_query($db_access, $sql4);

			$numCom = mysqli_num_rows($sql_run4);

			if(mysqli_num_rows($sql_run) == 0)
			{
				echo '<article class="entry">

             <!-- <div class="entry-img">
                <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid">
              </div>-->

              <h2 class="entry-title">
                <p>'.$heading.'</p>
              </h2>
              </article>';
			}
			else
			{
				echo '<article class="entry"> <b style="color: blue;">Post #'.$Id.'</b>

	             <!-- <div class="entry-img">
	                <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid">
	              </div>-->

	              <h2 class="entry-title">
	                <p>'.$heading.'</p>
	              </h2>

	              <div class="entry-meta">
	                <ul>
	                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <form action="profile.php" method="post"><input type="hidden" value='.$Post_email.' name="postemail"><button type=submit class="cmmnt">'.$name.' '.$lname.'</button></form></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="#"><time datetime="2020-01-01">'.$date.'</time></a></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-cash"></i> <form action="sendtnbc.php" method="post"><input type="hidden" value='.$Post_email.' name="postemail"> <button type=submit class="cmmnt">Send TNBCs</button></form></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-chat-dots"></i> <form action="blog-single.php" method="post"> <input type="hidden" value='.$Id.' name="PID"> <button type=submit class="cmmnt">'.$numCom.' Comments</button></form></li>
	                </ul>
	              </div>

	              <div class="entry-content">
	                <p>'.$body.'</p>
	                <form action="assets/php/makecommentcat.php" method="post">
	                	<input type="hidden" value='.$Id.' name="postId">
	                	<input type="hidden" value='.$email.' name="userEmail">

	                	<input type="hidden" value='.$cat.' name="cat">

	                	<div class = "row">
	                		<div class = "col-md-10">
			                	<!--<input type="text" name="comment" class="comment">-->

			                	<div class="col form-group">
			                      <textarea name="comment" class="form-control" placeholder="Your Comment*"></textarea>
			                    </div>
			                </div>
			                <div class="col-md-2">
				           		
				                  <button type="submit" class="com-btn">Comment</button>
				                
			                </div>
		                </div>

	                </form>
	              </div>

	            </article>

	            ';
        	}
		}
	}

	function postNo($x)
	{
		include 'db_access.php';

		$tnbgms = $tnbgames;
		$prsnl = $personal;
		$bsnss = $business;


		//personal category
		$sql = "SELECT * FROM `posts` WHERE `Category` = 'personal'";
		$sql_run = mysqli_query($db_access, $sql);
		$cat0 = mysqli_num_rows($sql_run);


		//personal category
		$sql1 = "SELECT * FROM `posts` WHERE `Category` = 'personal'";
		$sql_run1 = mysqli_query($db_access, $sql1);
		$cat1 = mysqli_num_rows($sql_run1);


		//personal category
		$sql2 = "SELECT * FROM `posts` WHERE `Category` = 'personal'";
		$sql_run2 = mysqli_query($db_access, $sql2);
		$cat2 = mysqli_num_rows($sql_run2);


		$arrayName = array('personal' => $cat0, 'tnbgames' => $cat1, 'project' => $cat2);

		$arrayName['personal'];
	}


?>
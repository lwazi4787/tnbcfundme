<?php
	include 'functions.php';
	post();
?>
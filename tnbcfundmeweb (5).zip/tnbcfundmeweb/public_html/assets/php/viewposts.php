<?php
	include 'functions.php';
	viewposts();
?>
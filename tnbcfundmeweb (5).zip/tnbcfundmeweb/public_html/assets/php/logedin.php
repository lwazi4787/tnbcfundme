<?php

      session_start();

      $y = 2;

      if($_SESSION['logedin'] != 1)
      {
        header('Location: loging.php');
      }

   ?>
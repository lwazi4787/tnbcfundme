<?php
	include 'functions.php';
	confrmemail();
?>
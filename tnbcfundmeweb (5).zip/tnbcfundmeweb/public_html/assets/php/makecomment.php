<?php
	include 'functions.php';
	postcomment();
?>
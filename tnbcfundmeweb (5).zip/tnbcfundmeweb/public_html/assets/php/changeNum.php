<?php
	//include 'functions.php';
	changeNum();
?>
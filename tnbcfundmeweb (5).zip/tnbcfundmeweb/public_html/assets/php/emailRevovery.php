<?php
	include 'functions.php';
	passRecovery();
?>
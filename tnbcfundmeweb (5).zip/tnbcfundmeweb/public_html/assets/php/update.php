<?php
	include 'functions.php';
	editPost();
?>
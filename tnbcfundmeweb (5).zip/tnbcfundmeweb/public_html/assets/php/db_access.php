<?php

ob_start();
//connect vars
$severname = 'localhost';
$username = 'root';
$password = '';
$my_db = 'tnbcfundme';

//connect
$db_access = mysqli_connect($severname, $username, $password, $my_db);

//$dp_select = mysqli_select_db($conn, '');

if(!$db_access)
	{
		echo "Connection failed ".mysqli_connect_error();
	}
/*else
	{

	}*/
ob_end_flush();	

?>
<?php

	include 'db_access.php';

	//personal category
	$sql = "SELECT * FROM `posts` WHERE `Category` = 'project'";
	$sql_run = mysqli_query($db_access, $sql);
	$cat0 = mysqli_num_rows($sql_run);


	//personal category
	$sql1 = "SELECT * FROM `posts` WHERE `Category` = 'tnbgames'";
	$sql_run1 = mysqli_query($db_access, $sql1);
	$cat1 = mysqli_num_rows($sql_run1);


	//personal category
	$sql2 = "SELECT * FROM `posts` WHERE `Category` = 'personal'";
	$sql_run2 = mysqli_query($db_access, $sql2);
	$cat2 = mysqli_num_rows($sql_run2);


	$arrayName = array('personal' => $cat0, 'tnbgames' => $cat1, 'project' => $cat2);

	$arrayName['personal'];

?>
<?php
	include 'functions.php';
	replay();
?>
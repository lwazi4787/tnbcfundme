<?php
	include 'functions.php';
	login();
?>
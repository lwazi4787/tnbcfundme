<?php
	include 'functions.php';
	postcommentcat();
?>
<?php
	include 'db_access.php';
  //session_start();

	$email = $_POST['postemail'];


	$sql = "SELECT * FROM `users` WHERE `Email` = '$email'";
	$sql_run = mysqli_query($db_access, $sql);


	$row = mysqli_fetch_assoc($sql_run);


	$name = $row['Name'];
	$lname = $row['Last name'];
	$Email = $row['Email'];
  $Id = $row['Id'];


  if($email == $_SESSION['emai'])
  {

      echo '<article class="entry"> <b style="color: blue;"></b> <form action="makepost.php" method="post"><input type="hidden" value='.$Id.' name="id"><button type=submit class="cmmnt" id="edit"><i class="bi bi-pen edit"></i></button></form>  <form action="makepost.php" method="post"><input type="hidden" value='.$Email.' name="too"><button type=submit class="cmmnt" id="edit"><i class="bi bi-dm edit"></i>DM</button></form>

           <!-- <div class="entry-img">
              <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid">
            </div>-->

            <h2 class="entry-title">
                  <div class="row">
                <div class="col-md-6">
                    <h6>Name: '.$name.'</h6>
                </div>

                <div class="col-md-6">
                    <h6>Last Name: '.$lname.'</h6>
                </div><br><br>

                <div class="col-md-6">
                    <h6>Email: '.$Email.'</h6>
                </div>
            </div>
            </h2>

            <div class="entry-meta">
              <ul>
                
              </ul>
            </div>

            <div class="entry-content">
              <p></p>
              
            </div>

          </article>';

  }
  else
  {
    echo '<article class="entry"> <b style="color: blue;"></b>

           <!-- <div class="entry-img">
              <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid">
            </div>-->

            <h2 class="entry-title">
                  <div class="row">
                <div class="col-md-6">
                    <h6>Name: '.$name.'</h6>
                </div>

                <div class="col-md-6">
                    <h6>Last Name: '.$lname.'</h6>
                </div><br><br>

                <div class="col-md-6">
                    <h6>Email: '.$Email.'</h6>
                </div>
                <div class="col-md-12">
                    <h6>Biography</h6>
                </div>
                <div class="col-md-12">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
            </div>
            </h2>

            <div class="entry-meta">
              <ul>
                
              </ul>
            </div>

            <div class="entry-content">
              <p></p>
              
            </div>

          </article>';
  }
	


?>
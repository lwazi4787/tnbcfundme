<?php
	include 'functions.php';
	postNo();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>tnbcfundme</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <!--<link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">-->

  <link href="assets/boostrap4/css/bootstrap.min.css" rel="stylesheet">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  
  <link href="assets/css/style.css" rel="stylesheet">

  

  <style type="text/css">
  
    .cmmnt
    {
      border: none;
      background: rgba(0, 0, 00, 0);
      color: #999;
      padding: 0px;
      margin-left: -5px;
    }
    .comment
    {
      background: rgba(0, 0, 0, 0) !important;
    }
    .com-btn
    {
      border: none;
      padding: 1.5em;
    }
    .marg
    {
      margin-left: 20px;
    }
    .info_font
    {
      font-size: 2.5em;
      //background: red;
      border-radius: 50%;
      //color: blue;
      cursor: pointer;
      margin-left: 2em;
    }
    .notification_num
    {
      background: red;
      border-radius: 50%;
      padding: 3px;
      padding: 3px 7px;
      color: #fff;
      text-decoration-style: bold;
    }
    .notifications
    {
      border: 1px solid #dedede;
      padding: 1em;
      border-radius: 5px;
      cursor: pointer;
      margin-bottom: 2em;
      background: rgba(0, 0, 255, .1);
    }
    .btn-ntificatn
    {
      border:none;
      background: #fff;
      width: 100% !important;
      text-align: left;
    }
    .link-ntfctn
    {
      color: #333 !important;
      font-size: .9em !important;
    }
    .sub
    {
      border: none;
      background: #fff;
    }
    body
    {
      //background: rgba(0, 0, 00, 0.3) !important;
    }
    //.mymodal
    {
      border: 1px solid grey;
      //text-align: center;
      //width: 80%;
      margin: 2em auto;
      padding: 2em;
      border-radius: 5px;
      position: absolute;
      z-index: 100000;
      left: 25%;
      top: 25%;
      background: #fff;
      //display: none;
      overflow: hidden;
    }
    .modal-bg
    {
      position: fixed;
      top: 0px;
      left: 0px;
      width: 100%;
      height: 100vh;
      background: rgba(0,0,0, 0.6);
      z-index: 10;
      justify-content: center;
      align-items: center;
      overflow-y: none !important;
      visibility: hidden;
      opacity: 0;
      transition: ease-in-out;
    }
    .mymodal
    {
      justify-content: center;
      align-items: center;
      width: 50%;
      margin: 10em auto;
      background: #fff;
      padding: 2em;
      z-index: 100000;
      overflow-y: none !important;
    }
    .right
    {
      float: right;
      cursor: pointer;    
    }

  </style>

</head>

<body>

  <?php

    include 'assets/php/logedin.php';
    include 'assets/php/user name.php';
    include 'assets/php/notifications.php';

  ?>

    

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.php" class="logo d-flex align-items-center">
        <img src="assets/img/TNBC.png" alt="">
        <span>TNBC <small class="fundme">FUND<span class="me"><small class="me2">ME<small></span></small></span>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#">Home</a></li>
          <li><a class="nav-link scrollto" href="#">About</a></li>
          <!--<li><a class="nav-link scrollto" href="#services">Services</a></li>
          <li><a class="nav-link scrollto" href="#portfolio">Portfolio</a></li>-->
          <li><a class="nav-link scrollto" href="#">Donate</a></li>
          <li><a href="#">How it works</a></li>
          <li class="dropdown"><a href="#"><span>Fundraise for</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="http://localhost/tnbcfundmeweb/public_html/postcat.php?cat=project">Project Ideas</a></li>
              <!--<li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>-->
              <li><a href="http://localhost/tnbcfundmeweb/public_html/postcat.php?cat=tnbgames">TNB Games</a></li>
              <li><a href="http://localhost/tnbcfundmeweb/public_html/postcat.php?cat=personal">Personal</a></li>
              <!--<li><a href="#">Drop Down 4</a></li>-->
            </ul>
          </li>
          <li></li>

          

          <li>

            <form action="assets/php/logout.php" method="post">
              <button class="btn btn-danger marg">Logout</button>
            </form>
          </li>

          <li>
            <a href="http://localhost/tnbcfundmeweb/public_html/notifications.php#" class="link-ntfctn"><span class="bi bi-bell info_font"></span><span class="notification_num"><?php echo $x;   ?></span></a>
          </li>

        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header --><!-- End Header -->



  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <ol>
          <li><a href="index.php">Home</a></li>
          <li>Posts</li>
        </ol>
        <h2>Welcome <?php /*session_start();*/  echo $name.' '.$surname;  ?></h2>

      </div>
    </section><!-- End Breadcrumbs -->



    <div class="modal-bg" id="modal-bg">
    <div class="mymodal">
      
      <div class="row">
        <div>
          <h3>Make Post <span class="right" id="closemodal">X</span></h3>
        </div>
      </div>
      <hr>

      <div>
        <form action="assets/php/makepost.php" method = 'post'>

          <div class="row">
            
            <div class="col-lg-12">
              <input type="text" name="heading" class="input" placeholder="Heading">
            </div><br><br><br>

            <div class="col-lg-12">
              <label>Category</label>

              <select name="category" class="section">

                <option value="project">
                  Project Idea
                </option>

                <option value="tnbgames">
                  TNB Games
                </option>


                <option value="personal">
                  Personal
                </option>
                
              </select>
            </div><br><br>

          </div>

          <div class="col form-group">
            <textarea name="body" class="form-control" placeholder="Your Comment*"></textarea>
          </div>
          <hr>
          <button type="submit" class="btn btn-primary">Make Post</button>
        
        </form>
      </div>

      <div>
        <p></p>
      </div>

    </div>
    </div>




    <!--<script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>-->

    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-8 entries">

            <h4>Receant Posts</h4><br>

            <?php
                include 'assets/php/viewposts.php';
            ?>

            <!--<div class="blog-pagination">
              <ul class="justify-content-center">
                <li><a href="#">1</a></li>
                <li class="active"><a href="#">2</a></li>
                <li><a href="#">3</a></li>
              </ul>
            </div>-->

            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    


                    <div class="reply-form">
                <h4>Make post for funding request</h4>
                <form action="assets/php/makepost.php" method = 'post'>

                    <div class="row">
                      
                      <div class="col-lg-12">
                        <input type="text" name="heading" class="input" placeholder="Heading">
                      </div><br><br><br>

                      <div class="col-lg-12">
                        <label>Category</label>

                        <select name="category" class="section">

                          <option value="project">
                            Project Idea
                          </option>

                          <option value="tnbgames">
                            TNB Games
                          </option>


                          <option value="personal">
                            Personal
                          </option>
                          
                        </select>
                      </div><br><br>

                    </div>

                    <div class="col form-group">
                      <textarea name="body" class="form-control" placeholder="Your Comment*"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Make Post</button>
                  
                  

                </form>
                </div>



                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                  </div>
                </div>
              </div>
            </div>

          </div><!-- End blog entries list -->

          <div class="col-lg-4">

            <div class="sidebar">

              <button class="btn btn-primary" id="modalTrg" >Make Post</button>

              <!--<h3 class="sidebar-title">Search</h3>
              <div class="sidebar-item search-form">
                <form action="">
                  <input type="text">
                  <button type="submit"><i class="bi bi-search"></i></button>
                </form>
              </div><!-- End sidebar search formn--><br><br>

              <h3 class="sidebar-title">Categories</h3>
              <div class="sidebar-item categories">
                <ul>
                  <li><a href="http://localhost/tnbcfundmeweb/public_html/postcat.php?cat=project">Project <span>(<?php include 'assets/php/cart.php'; echo $cat0; ?>)</span></a></li>
                  <li><a href="http://localhost/tnbcfundmeweb/public_html/postcat.php?cat=tnbgames">TNB Games <span>(<?php echo $cat1; ?>)</span></a></li>
                  <li><a href="http://localhost/tnbcfundmeweb/public_html/postcat.php?cat=personal">Personal <span>(<?php echo $cat2; ?>)</span></a></li>
                </ul>
              </div><!-- End sidebar categories--><!--<button id="jstnjeh">jstnjeh</button>-->

              <!--<h3 class="sidebar-title">Recent Posts</h3>
              <div class="sidebar-item recent-posts">
                <div class="post-item clearfix">
                  <img src="assets/img/blog/blog-recent-1.jpg" alt="">
                  <h4><a href="blog-single.html">Nihil blanditiis at in nihil autem</a></h4>
                  <time datetime="2020-01-01">Jan 1, 2020</time>
                </div>

                <div class="post-item clearfix">
                  <img src="assets/img/blog/blog-recent-2.jpg" alt="">
                  <h4><a href="blog-single.html">Quidem autem et impedit</a></h4>
                  <time datetime="2020-01-01">Jan 1, 2020</time>
                </div>

                <div class="post-item clearfix">
                  <img src="assets/img/blog/blog-recent-3.jpg" alt="">
                  <h4><a href="blog-single.html">Id quia et et ut maxime similique occaecati ut</a></h4>
                  <time datetime="2020-01-01">Jan 1, 2020</time>
                </div>

                <div class="post-item clearfix">
                  <img src="assets/img/blog/blog-recent-4.jpg" alt="">
                  <h4><a href="blog-single.html">Laborum corporis quo dara net para</a></h4>
                  <time datetime="2020-01-01">Jan 1, 2020</time>
                </div>

                <div class="post-item clearfix">
                  <img src="assets/img/blog/blog-recent-5.jpg" alt="">
                  <h4><a href="blog-single.html">Et dolores corrupti quae illo quod dolor</a></h4>
                  <time datetime="2020-01-01">Jan 1, 2020</time>
                </div>

              </div><!-- End sidebar recent posts-->

              <!--<h3 class="sidebar-title">Tags</h3>
              <div class="sidebar-item tags">
                <ul>
                  <li><a href="#">App</a></li>
                  <li><a href="#">IT</a></li>
                  <li><a href="#">Business</a></li>
                  <li><a href="#">Mac</a></li>
                  <li><a href="#">Design</a></li>
                  <li><a href="#">Office</a></li>
                  <li><a href="#">Creative</a></li>
                  <li><a href="#">Studio</a></li>
                  <li><a href="#">Smart</a></li>
                  <li><a href="#">Tips</a></li>
                  <li><a href="#">Marketing</a></li>
                </ul>
              </div><!-- End sidebar tags-->

            </div><!-- End sidebar -->

          </div><!-- End blog sidebar -->

        </div>

      </div>
    </section><!-- End Blog Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/boostrap4/js/jquery.min.js"></script>
  <script src="assets/boostrap4/js/bootstrap.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

  
  <script src="assets/js/main.js"></script>

  <!--<script type="text/javascript">
    
    $('#btnmodal').on('click', function () {
      $('#exampleModal').modal('show');
    });

  </script>-->

  <script type="text/javascript">
    
    sessionStorage.setItem("lgn", 1);

  </script>


  <script type="text/javascript">
    
    var modalSelct = document.getElementById('modalTrg');
    var mymodal = document.getElementById('modal-bg');

    var mymodal2 = document.getElementById('modal-bg2');

    var closeModal = document.getElementById('closemodal');

    var edit = document.getElementsByClassName('edit');

    mymodal.style.visibility = 'hidden';


    modalSelct.addEventListener('click', modalShow);

    closeModal.addEventListener('click', modalClose);

    edit[0].addEventListener('click', modalShow2);

    function modalShow()
    {
      if(mymodal.style.visibility == 'hidden')
      {
        mymodal.style.visibility = 'visible';
        mymodal.style.opacity = '10';
      }
      else if(mymodal.style.visibility == 'visible')
      {
        mymodal.style.visibility = 'hidden';
        mymodal.style.opacity = '0';
      }
    }




    function modalShow2()
    {
      if(mymodal2.style.visibility == 'hidden')
      {
        mymodal2.style.visibility = 'visible';
        mymodal2.style.opacity = '10';
      }
      else if(mymodal2.style.visibility == 'visible')
      {
        mymodal2.style.visibility = 'hidden';
        mymodal2.style.opacity = '0';
      }
    }

    function modalClose()
    {
      mymodal.style.visibility = 'hidden';
      mymodal.style.opacity = '0';
    }

  </script>


  <script type="text/javascript">
    
    var rpltrg = document.getElementsByClassName('bi-reply-fill');

    var replymodal = document.getElementById('modal-reply');

    rpltrg.addEventListener('click', reply);

    function reply()
    {
      if(mymodal.style.visibility == 'hidden')
      {
        replymodal.style.visibility = 'visible';
        replymodal.style.opacity = '10';
      }
    }

  </script>


  <script type="text/javascript">
    

    $(document).ready(function() {
      var count = 2;
      var lastScrollTop = 10.5;

        $(window).scroll(function() {
           // var st = $(this).scrollTop();

            //if(st > lastScrollTop)
            {
                count = count + 2;
                //$(".entry").load("ajax.php", {
                   // commentNewCount: count
                });
            }
            //lastScrollTop = st + 10.5;
        });
    });


  </script>

</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>tnbcfundme</title>
  <meta content="" name="description">

  <meta content="" name="keywords">

  <!-- Favicons -->
  <!--<link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">-->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  
  <link href="assets/css/style.css" rel="stylesheet">

  

<style type="text/css">
  
  .fundme
  {
    color: #958c8c;
  }
  .me
  {
    color: #fff;
  }
  .me2
  {
    color: #666;
  }


  .login-form
  {
    width: 35%;
    margin: 0px auto;
    background: #ffeded;
    padding: 1em;

  }
  .inpt
  {
    width: 100%;
    border-radius: 5px;
    padding: .7em;
    border: 1px solid #dedede;
  }
  .submit
  {
    width: 100% !important;
    border: none;
    background: #f14141;
    padding: 1em;
    color: #fff;
    border-radius: 5px;
  }
  
  @media screen and (max-width:800px){
          .login-form
          {
            width: 100%;
            margin: 0px auto;
            background: #ffeded;
            padding: 1em;
          }
      
      
  }

</style>

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.php" class="logo d-flex align-items-center">
        <img src="assets/img/TNBC.png" alt="">
        <span>TNBC <small class="fundme">FUND<span class="me"><small class="me2">ME<small></span></small></span>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#">Home</a></li>
          <li><a class="nav-link scrollto" href="#">About</a></li>
          <!--<li><a class="nav-link scrollto" href="#services">Services</a></li>
          <li><a class="nav-link scrollto" href="#portfolio">Portfolio</a></li>-->
          <li><a class="nav-link scrollto" href="#">Donate</a></li>
          <li><a href="#">How it works</a></li>
          <li class="dropdown"><a href="#"><span>Fundraise for</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="http://localhost/tnbcfundmeweb/public_html/postcat.php?cat=project">Project Ideas</a></li>
              <!--<li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>-->
              <li><a href="http://localhost/tnbcfundmeweb/public_html/postcat.php?cat=tnbgames">TNB Games</a></li>
              <li><a href="http://localhost/tnbcfundmeweb/public_html/postcat.php?cat=personal">Personal</a></li>
              <!--<li><a href="#">Drop Down 4</a></li>-->
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="loging.php">Sign In</a></li>
          <li><a class="getstarted scrollto" href="signup.php">Start TNBC FundMe</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header --><br><br><br> <br><br>

  <!-- ======= Hero Section ======= -->
  <section id="contact" class="contact">

      <div class="container" data-aos="fade-up">

        <header class="section-header">
          <p>Please check your email and provide the code we sent you.</p>
        </header>

       <!-- <div class="">

          <div class="col-lg-12">
            <form action="php/signup.php" method="post" class="php-email-form">
              <div class="row gy-4">

                <div class="col-md-6">
                  <input type="text" name="name" class="form-control" placeholder="Your Name" required>
                </div>

                <div class="col-md-6 ">
                  <input type="text" class="form-control" name="lname" placeholder="Your LastName" required>
                </div>

                <div class="col-md-12">
                  <input type="email" class="form-control" name="email" placeholder="Email" required>
                </div>

                <div class="col-md-12">
                  <input type="password" class="form-control" name="password" placeholder="Password" required>
                </div>

                <div class="col-md-12">
                  <input type="submit" name="submit">
                </div>


                <div class="col-md-12 text-center">
                  <button type="submit">Sign Up</button>
                </div>




              </div>
            </form>

          </div>

        </div>

      </div>-->

      <!--<form action="assets/php/signup.php" method="post">

                  <input type="text" name="name">
                  <input type="text" name="lname">
                  
                  <input type="text" name="email">
                  <input type="text" name="password">
                  

                  <input type="submit" name="submit">
                </form>-->



                <div class="login-form">
                  <form action="assets/php/emailconfirm.php" method="post">
                    <div class="row">

                      <div class="col-md-12">
                        <input type="number" name="emailconf" class="inpt" placeholder="Email confirmation code" required>
                      </div><br><br><br>

                      <div class="col-md-12">
                        <input type="submit" class="submit">
                      </div>

                      </div>
                  </form>
                </div>

    </section>

    <!--<div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>FlexStart</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/flexstart-bootstrap-startup-template/ ->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>-->
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

  
  <script src="assets/js/main.js"></script>

</body>

</html>
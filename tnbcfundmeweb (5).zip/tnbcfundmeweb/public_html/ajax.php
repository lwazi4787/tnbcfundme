<?php

	
	//session_start();
	include 'assets/php/db_access.php';

	$email = "email@email.com";

	//$cat = $_GET['cat'];

	$newlim = $_POST['commentNewCount'];

	$sql = "SELECT * FROM `posts` ORDER BY `Id` DESC LIMIT 4";

	$sql_run = mysqli_query($db_access, $sql);

	while($row = mysqli_fetch_assoc($sql_run))
	{
		$heading = $row['Heading'];
		$body = $row['Body'];
		$category = $row['Category'];
		$date = $row['Date'];
		$Id = $row['Id'];
		$Post_email = $row['User email'];

		$sql2 = "SELECT * FROM `users` WHERE `Email` = '$Post_email'";

		$sql_run2 = mysqli_query($db_access, $sql2);

		$row2 = mysqli_fetch_assoc($sql_run2);

		$name = $row2['Name'];
		$lname = $row2['Last name'];

		$sql4 = "SELECT * FROM `comments` WHERE `Post id` = '$Id'";

		$sql_run4 = mysqli_query($db_access, $sql4);

		$numCom = mysqli_num_rows($sql_run4);

		if(mysqli_num_rows($sql_run) == 0)
		{
			echo '<article class="entry">

         <!-- <div class="entry-img">
            <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid">
          </div>-->

          <h2 class="entry-title">
            <p>'.$heading.'</p>
          </h2>
          </article>';
		}
		else if($Post_email == $email)
			{
				echo '<article class="entry" id="art"> <b style="color: blue;"> <form action="makepost.php" method="post"><input type="hidden" value='.$Id.' name="id"><button type=submit class="cmmnt" id="edit"><i class="bi bi-pen edit"></i></button></b>

	             <!-- <div class="entry-img">
	                <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid">
	              </div>-->

	              <h2 class="entry-title">
	                <p>'.$heading.'</p>
	              </h2>

	              <div class="entry-meta">
	                <ul>
	                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <form action="profile.php" method="post"><input type="hidden" value='.$Post_email.' name="postemail"><button type=submit class="cmmnt">'.$name.' '.$lname.'</button></form></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="#"><time datetime="2020-01-01">'.$date.'</time></a></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-cash"></i> <form action="sendtnbc.php" method="post"><input type="hidden" value='.$Post_email.' name="postemail"> <button type=submit class="cmmnt">Send TNBCs</button></form></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-chat-dots"></i> <form action="blog-single.php" method="post"> <input type="hidden" value='.$Id.' name="PID"> <button type=submit class="cmmnt">'.$numCom.' Comments</button></form></li>
	                </ul>
	              </div>

	              <div class="entry-content">
	                <p>'.$body.'</p>
	                <form action="assets/php/makecomment.php" method="post">
	                	<input type="hidden" value='.$Id.' name="postId">
	                	<input type="hidden" value='.$email.' name="userEmail">

	                	<div class = "row">
	                		<div class = "col-md-10">
			                	<!--<input type="text" name="comment" class="comment">-->

			                	<div class="col form-group">
			                      <textarea name="comment" class="form-control" placeholder="Your Comment*"></textarea>
			                    </div>
			                </div>
			                <div class="col-md-2">
				           		
				                  <button type="submit" class="com-btn">Comment</button>
				                
			                </div>
		                </div>

	                </form>
	              </div>

	            </article>









	            <div class="modal-bg" id="modal-bg2">
			    <div class="mymodal">
			      
			      <div class="row">
			        <div>
			          <h3>Make Post <span class="right" id="closemodal">X</span></h3>
			        </div>
			      </div>
			      <hr>

			      <div>
			        <form action="assets/php/makepost.php" method = "post">

			          <div class="row">
			            
			            <div class="col-lg-12">
			              <input type="text" name="heading" class="input" value='.$heading.'><input type="text" name="heading" class="input" value='.$heading.'>
			            </div><br><br><br>

			            <div class="col-lg-12">
			              <label>Category</label>

			              <select name="category" class="section">

			                <option value="project">
			                  Project Idea
			                </option>

			                <option value="tnbgames">
			                  TNB Games
			                </option>


			                <option value="personal">
			                  Personal
			                </option>
			                
			              </select>
			            </div><br><br>

			          </div>

			          <div class="col form-group">
			            <textarea name="body" class="form-control" placeholder="Your Comment*"></textarea>
			          </div>
			          <hr>
			          <button type="submit" class="btn btn-primary">Make Post</button>
			        
			        </form>
			      </div>

			      <div>
			        <p></p>
			      </div>

			    </div>
			    </div>











	           ';
        	}
        	else
        	{
        		echo '<article class="entry" id="art">

	             <!-- <div class="entry-img">
	                <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid">
	              </div>-->

	              <h2 class="entry-title">
	                <p>'.$heading.'</p>
	              </h2>

	              <div class="entry-meta">
	                <ul>
	                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <form action="profile.php" method="post"><input type="hidden" value='.$Post_email.' name="postemail"><button type=submit class="cmmnt">'.$name.' '.$lname.'</button></form></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="#"><time datetime="2020-01-01">'.$date.'</time></a></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-cash"></i> <form action="sendtnbc.php" method="post"><input type="hidden" value='.$Post_email.' name="postemail"> <button type=submit class="cmmnt">Send TNBCs</button></form></li>

	                  <li class="d-flex align-items-center"><i class="bi bi-chat-dots"></i> <form action="blog-single.php" method="post"> <input type="hidden" value='.$Id.' name="PID"> <button type=submit class="cmmnt">'.$numCom.' Comments</button></form></li>
	                </ul>
	              </div>

	              <div class="entry-content">
	                <p>'.$body.'</p>
	                <form action="assets/php/makecomment.php" method="post">
	                	<input type="hidden" value='.$Id.' name="postId">
	                	<input type="hidden" value='.$email.' name="userEmail">

	                	<div class = "row">
	                		<div class = "col-md-10">
			                	<!--<input type="text" name="comment" class="comment">-->

			                	<div class="col form-group">
			                      <textarea name="comment" class="form-control" placeholder="Your Comment*"></textarea>
			                    </div>
			                </div>
			                <div class="col-md-2">
				           		
				                  <button type="submit" class="com-btn">Comment</button>
				                
			                </div>
		                </div>

	                </form>
	              </div>

	            </article>

	            ';
        	}
		}

?>